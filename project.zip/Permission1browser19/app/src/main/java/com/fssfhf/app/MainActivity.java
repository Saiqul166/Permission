package com.fssfhf.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int RECEIVER_NOT_EXPORTED_VAL = 0x4;

    private FrameLayout webViewContainer, fullscreenContainer;
    private View homeLayout, tabSwitcherOverlay, topToolbar, downloadPageOverlay, historyPageOverlay, mainContentFrame;
    private View privateVaultOverlay, pinEntryOverlay;
    private EditText urlInput;
    private ImageView securityIcon;
    private TextView tabCountText, txtEmptyDownloads, txtEmptyHistory, txtEmptyVault, txtPinTitle;
    private ProgressBar progressBar;
    private LinearLayout historyContainer;
    private RecyclerView tabRecyclerView, downloadRecyclerView, fullHistoryRecyclerView, vaultRecyclerView, shortcutRecyclerView;
    private GridLayout pinKeypad;
    private View[] pinDots = new View[4];

    // Video Player Components
    private View videoPlayerOverlay, gestureIndicator, centerControls, videoTopControls, videoBottomControls, touchOverlay;
    private View doubleTapLeft, doubleTapRight;
    private VideoView videoView;
    private SeekBar videoSeekBar;
    private ImageButton btnVideoPlayPauseCenter, btnLockVideo;
    private TextView txtVideoTime, gestureText, txtVideoTitle;
    private ImageView gestureIcon;
    private Handler videoHandler = new Handler();
    private GestureDetector gestureDetector;
    private AudioManager audioManager;
    private boolean isVideoLocked = false;
    private boolean isControlsVisible = false;
    private Runnable hideControlsRunnable;
    
    // Vault Video Playback Variable
    private File vaultTempFile = null;

    private List<WebView> tabList = new ArrayList<>();
    private List<DownloadItem> downloadList = new ArrayList<>();
    private List<VaultItem> vaultList = new ArrayList<>();
    private List<HistoryItem> fullHistoryList = new ArrayList<>();
    private List<ShortcutItem> shortcutList = new ArrayList<>();
    
    private DownloadAdapter downloadAdapter;
    private VaultAdapter vaultAdapter;
    private HistoryAdapter historyAdapter;
    private ShortcutAdapter shortcutAdapter;
    
    private int currentTabIndex = -1;
    private String lastApprovedUrl = "";
    private boolean isSecurityEnabled = true;
    private boolean isStrictDomainLockEnabled = false; // New Variable for Strict Domain Lock
    
    // Vault & PIN Variables
    private String currentPinInput = "";
    private boolean isSettingNewPin = false;
    private static final String KEY_VAULT_PIN = "vault_pin_code";
    private static final String PRIVATE_DIR_NAME = ".private_vault";
    
    private float lastTouchX, lastTouchY;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    
    private static final String PREFS_NAME = "BrowserPrefs";
    private static final String KEY_HISTORY = "full_history_v5";
    private static final String KEY_SECURITY = "security_enabled";
    private static final String KEY_STRICT_DOMAIN = "strict_domain_enabled"; // New Key
    private static final int STORAGE_PERMISSION_CODE = 1001;
    private static final String CHANNEL_ID = "download_channel";
    private static final String ACTION_CANCEL_DOWNLOAD = "com.fssfhf.app.CANCEL_DOWNLOAD";
    private static final String EXTRA_OPEN_DOWNLOADS = "open_downloads";

    public static class DownloadItem {
        String url, userAgent, mimetype, contentDisposition;
        String fileName;
        long totalSize = 0;
        long downloadedSize = 0;
        int progress = 0;
        boolean isCompleted = false;
        boolean isPaused = false;
        boolean isCanceled = false;
        boolean isFailed = false;
        String filePath;
        int notificationId;
        Thread downloadThread;

        DownloadItem(String url, String fileName) {
            this.url = url;
            this.fileName = fileName;
            this.notificationId = (int) System.currentTimeMillis();
        }
    }
    
    public static class VaultItem {
        String fileName;
        String filePath;
        long size;
        
        VaultItem(String fileName, String filePath, long size) {
            this.fileName = fileName;
            this.filePath = filePath;
            this.size = size;
        }
    }

    public static class HistoryItem {
        String title, url;
        HistoryItem(String title, String url) {
            this.title = title;
            this.url = url;
        }
    }

    public static class ShortcutItem {
        public String id;
        public String title;
        public String url;
        public String icon_url;

        public ShortcutItem() {
            // Default constructor required for calls to DataSnapshot.getValue(ShortcutItem.class)
        }
    }

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_CANCEL_DOWNLOAD.equals(intent.getAction())) {
                int id = intent.getIntExtra("notifId", -1);
                for (DownloadItem item : downloadList) {
                    if (item.notificationId == id) {
                        cancelDownload(item);
                        break;
                    }
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        isSecurityEnabled = prefs.getBoolean(KEY_SECURITY, true);
        isStrictDomainLockEnabled = prefs.getBoolean(KEY_STRICT_DOMAIN, false); // Load Strict Domain Lock state
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, new IntentFilter(ACTION_CANCEL_DOWNLOAD), RECEIVER_NOT_EXPORTED_VAL);
        } else {
            registerReceiver(downloadReceiver, new IntentFilter(ACTION_CANCEL_DOWNLOAD));
        }
        
        createNotificationChannel();
        initViews();
        initVaultViews();
        setupClickListeners();
        loadDynamicShortcuts();
        loadHistoryUI();
        loadExistingDownloads();
        setupGestureDetector();
        checkAppUpdate();
        
        addNewTab("about:blank");

        if (getIntent().getBooleanExtra(EXTRA_OPEN_DOWNLOADS, false)) {
            showDownloads();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra(EXTRA_OPEN_DOWNLOADS, false)) {
            showDownloads();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Security: Close video and relock file if app goes to background
        if (videoPlayerOverlay.getVisibility() == View.VISIBLE || vaultTempFile != null) {
            closeVideoPlayer();
        }
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) {}
        videoHandler.removeCallbacksAndMessages(null);
        // Ensure file is relocked if destroyed
        if (vaultTempFile != null && vaultTempFile.exists()) {
            File lockedFile = new File(vaultTempFile.getAbsolutePath() + ".locked");
            vaultTempFile.renameTo(lockedFile);
        }
        super.onDestroy();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Downloads", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void initViews() {
        topToolbar = findViewById(R.id.topToolbar);
        webViewContainer = findViewById(R.id.webViewContainer);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);
        mainContentFrame = findViewById(R.id.mainContentFrame);
        homeLayout = findViewById(R.id.homeLayout);
        tabSwitcherOverlay = findViewById(R.id.tabSwitcherOverlay);
        downloadPageOverlay = findViewById(R.id.downloadPageOverlay);
        historyPageOverlay = findViewById(R.id.historyPageOverlay);
        
        urlInput = findViewById(R.id.urlInput);
        securityIcon = findViewById(R.id.securityIcon);
        
        tabCountText = findViewById(R.id.tabCountText);
        progressBar = findViewById(R.id.progressBar);
        historyContainer = findViewById(R.id.historyContainer);
        txtEmptyDownloads = findViewById(R.id.txtEmptyDownloads);
        txtEmptyHistory = findViewById(R.id.txtEmptyHistory);

        // Video Player Views
        videoPlayerOverlay = findViewById(R.id.videoPlayerOverlay);
        videoView = findViewById(R.id.videoView);
        touchOverlay = findViewById(R.id.touchOverlay);
        videoSeekBar = findViewById(R.id.videoSeekBar);
        btnVideoPlayPauseCenter = findViewById(R.id.btnVideoPlayPauseCenter);
        txtVideoTime = findViewById(R.id.txtVideoTime);
        txtVideoTitle = findViewById(R.id.txtVideoTitle);
        gestureIndicator = findViewById(R.id.gestureIndicator);
        gestureIcon = findViewById(R.id.gestureIcon);
        gestureText = findViewById(R.id.gestureText);
        centerControls = findViewById(R.id.centerControls);
        videoTopControls = findViewById(R.id.videoTopControls);
        videoBottomControls = findViewById(R.id.videoBottomControls);
        btnLockVideo = findViewById(R.id.btnLockVideo);
        doubleTapLeft = findViewById(R.id.doubleTapLeft);
        doubleTapRight = findViewById(R.id.doubleTapRight);
        
        tabRecyclerView = findViewById(R.id.tabRecyclerView);
        tabRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        downloadRecyclerView = findViewById(R.id.downloadRecyclerView);
        downloadRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        downloadAdapter = new DownloadAdapter();
        downloadRecyclerView.setAdapter(downloadAdapter);

        fullHistoryRecyclerView = findViewById(R.id.fullHistoryRecyclerView);
        fullHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        historyAdapter = new HistoryAdapter();
        fullHistoryRecyclerView.setAdapter(historyAdapter);

        // Dynamic Shortcuts RecyclerView
        shortcutRecyclerView = findViewById(R.id.shortcutRecyclerView);
        shortcutRecyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        shortcutAdapter = new ShortcutAdapter();
        shortcutRecyclerView.setAdapter(shortcutAdapter);

        hideControlsRunnable = this::hideVideoControls;
    }
    
    private void initVaultViews() {
        privateVaultOverlay = findViewById(R.id.privateVaultOverlay);
        pinEntryOverlay = findViewById(R.id.pinEntryOverlay);
        vaultRecyclerView = findViewById(R.id.vaultRecyclerView);
        txtEmptyVault = findViewById(R.id.txtEmptyVault);
        txtPinTitle = findViewById(R.id.txtPinTitle);
        pinKeypad = findViewById(R.id.pinKeypad);
        
        pinDots[0] = findViewById(R.id.pinDot1);
        pinDots[1] = findViewById(R.id.pinDot2);
        pinDots[2] = findViewById(R.id.pinDot3);
        pinDots[3] = findViewById(R.id.pinDot4);
        
        vaultRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        vaultAdapter = new VaultAdapter();
        vaultRecyclerView.setAdapter(vaultAdapter);
        
        // Build Keypad
        for (int i = 1; i <= 9; i++) {
            addKeypadButton(String.valueOf(i));
        }
        addKeypadButton(""); // Empty space
        addKeypadButton("0");
        addKeypadButton("⌫"); // Backspace
        
        findViewById(R.id.btnOpenVault).setOnClickListener(v -> openVault());
        findViewById(R.id.btnCloseVault).setOnClickListener(v -> privateVaultOverlay.setVisibility(View.GONE));
        findViewById(R.id.btnCancelPin).setOnClickListener(v -> {
            pinEntryOverlay.setVisibility(View.GONE);
            currentPinInput = "";
            updatePinDots();
        });
    }
    
    private void addKeypadButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(20);
        btn.setTextColor(0xFFFFFFFF);
        btn.setBackgroundResource(android.R.color.transparent);
        
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 180;
        params.height = 180;
        params.setMargins(10, 10, 10, 10);
        btn.setLayoutParams(params);
        
        if (!text.isEmpty()) {
            btn.setOnClickListener(v -> {
                if (text.equals("⌫")) {
                    if (currentPinInput.length() > 0) {
                        currentPinInput = currentPinInput.substring(0, currentPinInput.length() - 1);
                        updatePinDots();
                    }
                } else {
                    if (currentPinInput.length() < 4) {
                        currentPinInput += text;
                        updatePinDots();
                        if (currentPinInput.length() == 4) {
                            verifyPin();
                        }
                    }
                }
            });
        } else {
            btn.setEnabled(false);
        }
        pinKeypad.addView(btn);
    }
    
    private void updatePinDots() {
        for (int i = 0; i < 4; i++) {
            if (i < currentPinInput.length()) {
                pinDots[i].setBackgroundColor(0xFF3b82f6); // Filled
            } else {
                pinDots[i].setBackgroundResource(R.drawable.tab_count_bg); // Empty
            }
        }
    }
    
    private void openVault() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedPin = prefs.getString(KEY_VAULT_PIN, "");
        
        currentPinInput = "";
        updatePinDots();
        pinEntryOverlay.setVisibility(View.VISIBLE);
        
        if (savedPin.isEmpty()) {
            isSettingNewPin = true;
            txtPinTitle.setText("নতুন পিন সেট করুন");
        } else {
            isSettingNewPin = false;
            txtPinTitle.setText("পিন দিন");
        }
    }
    
    private void verifyPin() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        
        if (isSettingNewPin) {
            prefs.edit().putString(KEY_VAULT_PIN, currentPinInput).apply();
            Toast.makeText(this, "পিন সেট করা হয়েছে", Toast.LENGTH_SHORT).show();
            pinEntryOverlay.setVisibility(View.GONE);
            showVaultContent();
        } else {
            String savedPin = prefs.getString(KEY_VAULT_PIN, "");
            if (currentPinInput.equals(savedPin)) {
                pinEntryOverlay.setVisibility(View.GONE);
                showVaultContent();
            } else {
                Toast.makeText(this, "ভুল পিন!", Toast.LENGTH_SHORT).show();
                currentPinInput = "";
                updatePinDots();
            }
        }
    }
    
    private void showVaultContent() {
        privateVaultOverlay.setVisibility(View.VISIBLE);
        loadVaultFiles();
    }
    
    private void loadVaultFiles() {
        vaultList.clear();
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Permission Browser");
        File vaultDir = new File(downloadDir, PRIVATE_DIR_NAME);
        
        if (!vaultDir.exists()) {
            vaultDir.mkdirs();
            // Create .nomedia to hide from gallery
            try { new File(vaultDir, ".nomedia").createNewFile(); } catch (IOException ignored) {}
        }
        
        File[] files = vaultDir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.getName().equals(".nomedia")) continue;
                if (f.getName().endsWith(".locked")) {
                    String originalName = f.getName().replace(".locked", "");
                    vaultList.add(new VaultItem(originalName, f.getAbsolutePath(), f.length()));
                }
            }
        }
        
        txtEmptyVault.setVisibility(vaultList.isEmpty() ? View.VISIBLE : View.GONE);
        vaultAdapter.notifyDataSetChanged();
    }
    
    private void lockFile(DownloadItem item) {
        if (item.filePath == null) return;
        File originalFile = new File(item.filePath);
        if (!originalFile.exists()) return;
        
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Permission Browser");
        File vaultDir = new File(downloadDir, PRIVATE_DIR_NAME);
        if (!vaultDir.exists()) vaultDir.mkdirs();
        
        File lockedFile = new File(vaultDir, originalFile.getName() + ".locked");
        
        if (originalFile.renameTo(lockedFile)) {
            Toast.makeText(this, "ফাইলটি ভল্টে লক করা হয়েছে", Toast.LENGTH_SHORT).show();
            downloadList.remove(item);
            downloadAdapter.notifyDataSetChanged();
            updateEmptyDownloadState();
        } else {
            Toast.makeText(this, "লক করতে ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void unlockFile(VaultItem item) {
        File lockedFile = new File(item.filePath);
        if (!lockedFile.exists()) return;
        
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Permission Browser");
        File unlockedFile = new File(downloadDir, item.fileName);
        
        if (lockedFile.renameTo(unlockedFile)) {
            Toast.makeText(this, "ফাইলটি আনলক করা হয়েছে", Toast.LENGTH_SHORT).show();
            vaultList.remove(item);
            vaultAdapter.notifyDataSetChanged();
            txtEmptyVault.setVisibility(vaultList.isEmpty() ? View.VISIBLE : View.GONE);
            
            // Refresh download list
            loadExistingDownloads();
        } else {
            Toast.makeText(this, "আনলক করতে ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void playVaultVideo(VaultItem item) {
        File lockedFile = new File(item.filePath);
        if (!lockedFile.exists()) {
            Toast.makeText(this, "ফাইল পাওয়া যাচ্ছে না", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Temporary file path (remove .locked)
        File tempFile = new File(item.filePath.replace(".locked", ""));
        
        if (lockedFile.renameTo(tempFile)) {
            vaultTempFile = tempFile;
            openVideoPlayer(tempFile.getAbsolutePath());
            Toast.makeText(this, "সিকিউর প্লেয়ার চালু হচ্ছে...", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "ফাইল ডিক্রিপ্ট করতে ব্যর্থ", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupClickListeners() {
        findViewById(R.id.btnTabSwitcher).setOnClickListener(v -> showTabSwitcher());
        findViewById(R.id.btnAddTab).setOnClickListener(v -> { addNewTab("about:blank"); hideTabSwitcher(); });
        findViewById(R.id.btnHome).setOnClickListener(v -> showHomePage());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMenu());
        findViewById(R.id.btnBackFromDownloads).setOnClickListener(v -> hideDownloads());
        findViewById(R.id.btnBackFromHistory).setOnClickListener(v -> hideHistory());
        findViewById(R.id.btnClearFullHistory).setOnClickListener(v -> confirmClearHistory());

        findViewById(R.id.btnCloseVideo).setOnClickListener(v -> closeVideoPlayer());
        btnVideoPlayPauseCenter.setOnClickListener(v -> toggleVideoPlayback());
        findViewById(R.id.btnVideoRewind).setOnClickListener(v -> {
            videoView.seekTo(Math.max(0, videoView.getCurrentPosition() - 10000));
            showDoubleTapFeedback(doubleTapLeft);
            resetControlsTimer();
        });
        findViewById(R.id.btnVideoForward).setOnClickListener(v -> {
            videoView.seekTo(Math.min(videoView.getDuration(), videoView.getCurrentPosition() + 10000));
            showDoubleTapFeedback(doubleTapRight);
            resetControlsTimer();
        });
        
        btnLockVideo.setOnClickListener(v -> {
            isVideoLocked = !isVideoLocked;
            btnLockVideo.setImageResource(isVideoLocked ? android.R.drawable.ic_lock_lock : R.drawable.ic_security);
            if (isVideoLocked) {
                hideVideoControls();
                Toast.makeText(this, "প্লেয়ার লক করা হয়েছে", Toast.LENGTH_SHORT).show();
            } else {
                showVideoControls();
            }
        });

        videoSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) videoView.seekTo(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { videoHandler.removeCallbacks(hideControlsRunnable); }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { resetControlsTimer(); }
        });

        // Address Bar URL Input
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                performSearch(urlInput.getText().toString().trim());
                return true;
            }
            return false;
        });

        urlInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                urlInput.selectAll();
            }
        });
    }

    private void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void toggleVideoPlayback() {
        if (videoView.isPlaying()) {
            videoView.pause();
            btnVideoPlayPauseCenter.setImageResource(R.drawable.ic_play);
            videoHandler.removeCallbacks(hideControlsRunnable);
        } else {
            videoView.start();
            btnVideoPlayPauseCenter.setImageResource(R.drawable.ic_pause);
            resetControlsTimer();
        }
    }

    private void showVideoControls() {
        if (isVideoLocked) {
            videoTopControls.setVisibility(View.VISIBLE);
            videoTopControls.animate().alpha(1f).setDuration(300).start();
            videoHandler.removeCallbacks(hideControlsRunnable);
            videoHandler.postDelayed(() -> {
                videoTopControls.animate().alpha(0f).setDuration(300).withEndAction(() -> videoTopControls.setVisibility(View.GONE)).start();
            }, 3000);
            return;
        }
        isControlsVisible = true;
        centerControls.setVisibility(View.VISIBLE);
        videoTopControls.setVisibility(View.VISIBLE);
        videoBottomControls.setVisibility(View.VISIBLE);
        
        centerControls.animate().alpha(1f).setDuration(300).start();
        videoTopControls.animate().alpha(1f).setDuration(300).start();
        videoBottomControls.animate().alpha(1f).setDuration(300).start();
        
        resetControlsTimer();
    }

    private void hideVideoControls() {
        isControlsVisible = false;
        centerControls.animate().alpha(0f).setDuration(300).withEndAction(() -> centerControls.setVisibility(View.GONE)).start();
        videoTopControls.animate().alpha(0f).setDuration(300).withEndAction(() -> videoTopControls.setVisibility(View.GONE)).start();
        videoBottomControls.animate().alpha(0f).setDuration(300).withEndAction(() -> videoBottomControls.setVisibility(View.GONE)).start();
    }

    private void resetControlsTimer() {
        videoHandler.removeCallbacks(hideControlsRunnable);
        videoHandler.postDelayed(hideControlsRunnable, 5000);
    }

    private Runnable hideGestureRunnable = () -> {
        if (gestureIndicator.getVisibility() == View.VISIBLE) {
            gestureIndicator.animate().alpha(0f).setDuration(300).withEndAction(() -> gestureIndicator.setVisibility(View.GONE)).start();
        }
    };

    private void showDoubleTapFeedback(View view) {
        view.setVisibility(View.VISIBLE);
        view.setAlpha(1f);
        view.animate().alpha(0f).setDuration(500).setStartDelay(300).withEndAction(() -> view.setVisibility(View.GONE)).start();
    }

    private void setupGestureDetector() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (isVideoLocked) return false;
                
                float deltaY = e1.getY() - e2.getY();
                float deltaX = e1.getX() - e2.getX();
                float absDeltaX = Math.abs(deltaX);
                float absDeltaY = Math.abs(deltaY);

                if (absDeltaX > absDeltaY) {
                    if (absDeltaX > 10) {
                        int seekAmount = (int) (-deltaX * 50);
                        int newPos = videoView.getCurrentPosition() + seekAmount;
                        if (newPos < 0) newPos = 0;
                        if (newPos > videoView.getDuration()) newPos = videoView.getDuration();
                        videoView.seekTo(newPos);
                        
                        String sign = seekAmount > 0 ? "+" : "";
                        showGestureIndicator(seekAmount > 0 ? android.R.drawable.ic_media_ff : android.R.drawable.ic_media_rew, 
                                            sign + (seekAmount / 1000) + "s");
                    }
                } else {
                    if (absDeltaY > 10) {
                        int screenHeight = videoPlayerOverlay.getHeight();
                        if (e1.getX() < videoPlayerOverlay.getWidth() / 2) {
                            adjustVolume(deltaY / screenHeight);
                        } else {
                            adjustBrightness(deltaY / screenHeight);
                        }
                    }
                }
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (isControlsVisible) {
                    hideVideoControls();
                } else {
                    showVideoControls();
                }
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (isVideoLocked) return false;
                if (e.getX() < videoPlayerOverlay.getWidth() / 2) {
                    videoView.seekTo(Math.max(0, videoView.getCurrentPosition() - 10000));
                    showDoubleTapFeedback(doubleTapLeft);
                } else {
                    videoView.seekTo(Math.min(videoView.getDuration(), videoView.getCurrentPosition() + 10000));
                    showDoubleTapFeedback(doubleTapRight);
                }
                return true;
            }
        });

        touchOverlay.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                videoHandler.removeCallbacks(hideGestureRunnable);
                videoHandler.postDelayed(hideGestureRunnable, 500);
            }
            return gestureDetector.onTouchEvent(event);
        });
    }

    private void adjustBrightness(float percent) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        float brightness = lp.screenBrightness;
        if (brightness < 0) brightness = 0.5f;
        brightness += percent;
        if (brightness < 0.01f) brightness = 0.01f;
        if (brightness > 1.0f) brightness = 1.0f;
        lp.screenBrightness = brightness;
        getWindow().setAttributes(lp);
        showGestureIndicator(android.R.drawable.ic_menu_compass, (int)(brightness * 100) + "%");
    }

    private void adjustVolume(float percent) {
        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int delta = (int) (percent * maxVol * 1.5);
        int newVol = currentVol + delta;
        if (newVol < 0) newVol = 0;
        if (newVol > maxVol) newVol = maxVol;
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0);
        showGestureIndicator(android.R.drawable.ic_lock_silent_mode_off, (int)((float)newVol/maxVol * 100) + "%");
    }

    private void showGestureIndicator(int iconRes, String text) {
        gestureIndicator.setVisibility(View.VISIBLE);
        gestureIndicator.setAlpha(1f);
        gestureIcon.setImageResource(iconRes);
        gestureText.setText(text);
        
        videoHandler.removeCallbacks(hideGestureRunnable);
        videoHandler.postDelayed(hideGestureRunnable, 800);
    }

    private void setupWebViewSettings(WebView webView) {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        
        webView.addJavascriptInterface(new MediaDetectionInterface(), "MediaInterface");
        webView.setWebViewClient(new GatekeeperClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (view == getCurrentWebView()) {
                    progressBar.setProgress(newProgress);
                    progressBar.setVisibility(newProgress == 100 ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    onHideCustomView();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                fullscreenContainer.addView(customView);
                fullscreenContainer.setVisibility(View.VISIBLE);
                mainContentFrame.setVisibility(View.GONE);
                topToolbar.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                fullscreenContainer.removeView(customView);
                fullscreenContainer.setVisibility(View.GONE);
                mainContentFrame.setVisibility(View.VISIBLE);
                topToolbar.setVisibility(View.VISIBLE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customView = null;
                customViewCallback = null;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            handleDownload(url, userAgent, contentDisposition, mimetype);
        });

        webView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                lastTouchX = event.getX();
                lastTouchY = event.getY();
            }
            return false;
        });

        webView.setOnLongClickListener(v -> {
            WebView.HitTestResult result = webView.getHitTestResult();
            if (result.getType() == WebView.HitTestResult.IMAGE_TYPE || result.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                showMediaMenu(result.getExtra(), "image");
                return true;
            }
            
            float density = getResources().getDisplayMetrics().density;
            String js = "javascript:(function() {" +
                    "  var x = " + (lastTouchX/density) + ";" +
                    "  var y = " + (lastTouchY/density) + ";" +
                    "  var el = document.elementFromPoint(x, y);" +
                    "  function findMedia(e) {" +
                    "    if (!e) return null;" +
                    "    if (e.tagName === 'VIDEO') return e;" +
                    "    if (e.tagName === 'IMG') return e;" +
                    "    return findMedia(e.parentElement);" +
                    "  }" +
                    "  var media = findMedia(el);" +
                    "  if (media) {" +
                    "    var src = media.currentSrc || media.src;" +
                    "    if (!src && media.tagName === 'VIDEO') {" +
                    "      var sources = media.getElementsByTagName('source');" +
                    "      if (sources.length > 0) src = sources[0].src;" +
                    "    }" +
                    "    if (src) MediaInterface.onMediaFound(src, media.tagName.toLowerCase());" +
                    "  }" +
                    "})()";
            webView.loadUrl(js);
            return true;
        });
    }

    private class MediaDetectionInterface {
        @JavascriptInterface
        public void onMediaFound(final String url, final String type) {
            runOnUiThread(() -> showMediaMenu(url, type));
        }
    }

    private void showMediaMenu(final String url, String type) {
        if (url == null || url.isEmpty()) return;
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View view = getLayoutInflater().inflate(R.layout.media_bottom_sheet, null);
        ImageView thumb = view.findViewById(R.id.imgMediaThumbnail);
        TextView urlText = view.findViewById(R.id.txtMediaUrl);
        TextView downloadLabel = view.findViewById(R.id.txtDownloadLabel);
        urlText.setText(url);

        boolean isVideo = type.equalsIgnoreCase("video") || url.contains(".mp4") || url.contains(".webm");
        if (isVideo) {
            thumb.setImageResource(android.R.drawable.ic_media_play);
            downloadLabel.setText("ভিডিও ডাউনলোড করুন");
            view.findViewById(R.id.optionPreview).setVisibility(View.GONE);
        } else {
            Glide.with(this).load(url).placeholder(R.drawable.ic_globe).into(thumb);
            downloadLabel.setText("ছবি ডাউনলোড করুন");
        }

        view.findViewById(R.id.optionDownload).setOnClickListener(v -> {
            dialog.dismiss();
            handleDownload(url, "", "", isVideo ? "video/mp4" : "image/jpeg");
        });
        
        view.findViewById(R.id.optionCopyLink).setOnClickListener(v -> {
            dialog.dismiss();
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Link", url));
            Toast.makeText(this, "লিংক কপি করা হয়েছে", Toast.LENGTH_SHORT).show();
        });

        dialog.setContentView(view);
        dialog.show();
    }

    private void handleDownload(String url, String userAgent, String contentDisposition, String mimetype) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && 
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
            return;
        }

        for (DownloadItem di : downloadList) {
            if (di.url.equals(url) && !di.isCompleted && !di.isFailed) {
                Toast.makeText(this, "এই ফাইলটি অলরেডি ডাউনলোড হচ্ছে", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Runnable startAction = () -> {
            showDownloads();
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
            DownloadItem item = new DownloadItem(url, fileName);
            item.userAgent = userAgent;
            item.mimetype = mimetype;
            item.contentDisposition = contentDisposition;
            downloadList.add(0, item);
            downloadAdapter.notifyItemInserted(0);
            startCustomDownload(item);
        };

        if (!isSecurityEnabled) {
            startAction.run();
        } else {
            new MaterialAlertDialogBuilder(this)
                .setTitle("ডাউনলোড নিশ্চিত করুন")
                .setMessage("আপনি কি এই ফাইলটি ডাউনলোড করতে চান?")
                .setPositiveButton("ডাউনলোড", (dialog, which) -> startAction.run())
                .setNegativeButton("বাতিল", null)
                .show();
        }
    }

    private void startCustomDownload(final DownloadItem item) {
        item.downloadThread = new Thread(() -> {
            FileOutputStream output = null;
            InputStream input = null;
            boolean success = false;
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            long lastUpdateTime = 0;
            int lastProgress = -1;

            try {
                URL url = new URL(item.url);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                
                String cookies = CookieManager.getInstance().getCookie(item.url);
                if (cookies != null) connection.setRequestProperty("Cookie", cookies);
                
                if (item.userAgent != null && !item.userAgent.isEmpty()) {
                    connection.setRequestProperty("User-Agent", item.userAgent);
                } else {
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
                }
                
                connection.setRequestProperty("Referer", item.url);
                connection.setRequestProperty("Accept", "*/*");

                if (item.downloadedSize > 0) {
                    connection.setRequestProperty("Range", "bytes=" + item.downloadedSize + "-");
                }

                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.connect();

                int responseCode = connection.getResponseCode();
                if (responseCode < 200 || responseCode >= 300) {
                    if (responseCode != 416) throw new Exception("Server Error: " + responseCode);
                }

                if (item.totalSize <= 0) {
                    String length = connection.getHeaderField("Content-Length");
                    item.totalSize = (length != null) ? Long.parseLong(length) + item.downloadedSize : connection.getContentLength() + item.downloadedSize;
                }

                input = connection.getInputStream();
                File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Permission Browser");
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, item.fileName);
                item.filePath = file.getAbsolutePath();
                
                output = new FileOutputStream(file, item.downloadedSize > 0);

                byte[] data = new byte[8192];
                int count;
                
                while ((count = input.read(data)) != -1) {
                    if (item.isCanceled) {
                        break;
                    }
                    
                    while (item.isPaused) {
                        Thread.sleep(500);
                        if (item.isCanceled) break;
                    }
                    
                    output.write(data, 0, count);
                    item.downloadedSize += count;
                    if (item.totalSize > 0) {
                        item.progress = (int) (item.downloadedSize * 100 / item.totalSize);
                    }
                    
                    long currentTime = System.currentTimeMillis();
                    if (item.progress != lastProgress && (currentTime - lastUpdateTime > 1000)) {
                        lastUpdateTime = currentTime;
                        lastProgress = item.progress;
                        updateNotification(item, notificationManager);
                        runOnUiThread(() -> downloadAdapter.notifyItemChanged(downloadList.indexOf(item)));
                    }
                }

                if (!item.isCanceled) {
                    success = true;
                }

            } catch (Exception e) {
                e.printStackTrace();
                success = false;
            } finally {
                try { if (output != null) output.close(); } catch (IOException ignored) {}
                try { if (input != null) input.close(); } catch (IOException ignored) {}

                if (item.isCanceled) {
                    if (item.filePath != null) {
                        File f = new File(item.filePath);
                        if (f.exists()) f.delete();
                    }
                } else if (success) {
                    item.isCompleted = true;
                    item.progress = 100;
                    updateNotification(item, notificationManager);
                    runOnUiThread(() -> downloadAdapter.notifyItemChanged(downloadList.indexOf(item)));
                } else {
                    item.isFailed = true;
                    updateNotification(item, notificationManager);
                    runOnUiThread(() -> downloadAdapter.notifyItemChanged(downloadList.indexOf(item)));
                }
            }
        });
        item.downloadThread.start();
    }

    private void updateNotification(DownloadItem item, NotificationManagerCompat nm) {
        Intent cancelIntent = new Intent(ACTION_CANCEL_DOWNLOAD);
        cancelIntent.putExtra("notifId", item.notificationId);
        PendingIntent pCancel = PendingIntent.getBroadcast(this, item.notificationId, cancelIntent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.putExtra(EXTRA_OPEN_DOWNLOADS, true);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pOpen = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(item.fileName)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pOpen);

        if (item.isCompleted) {
            builder.setSmallIcon(android.R.drawable.stat_sys_download_done)
                   .setContentText("ডাউনলোড সম্পন্ন হয়েছে")
                   .setProgress(0, 0, false)
                   .setOngoing(false)
                   .setAutoCancel(true);
        } else if (item.isFailed) {
            builder.setSmallIcon(android.R.drawable.stat_notify_error)
                   .setContentText("ডাউনলোড ব্যর্থ হয়েছে")
                   .setProgress(0, 0, false)
                   .setOngoing(false)
                   .setAutoCancel(true);
        } else if (item.isPaused) {
            builder.setContentText("ডাউনলোড স্থগিত")
                   .setProgress(100, item.progress, false)
                   .setOngoing(false);
        } else {
            builder.setContentText("ডাউনলোড হচ্ছে: " + item.progress + "%")
                   .setProgress(100, item.progress, false)
                   .setOngoing(true)
                   .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বাতিল", pCancel);
        }
        nm.notify(item.notificationId, builder.build());
    }

    private void cancelDownload(DownloadItem item) {
        item.isCanceled = true;
        item.isPaused = false;
        NotificationManagerCompat.from(this).cancel(item.notificationId);
        
        if (item.filePath != null) {
            File f = new File(item.filePath);
            if (f.exists()) f.delete();
        }

        int pos = downloadList.indexOf(item);
        if (pos != -1) {
            downloadList.remove(pos);
            downloadAdapter.notifyItemRemoved(pos);
        }
        updateEmptyDownloadState();
    }

    private void deleteFile(DownloadItem item) {
        new MaterialAlertDialogBuilder(this)
            .setTitle("ফাইল মুছুন")
            .setMessage("আপনি কি নিশ্চিতভাবে এই ফাইলটি মেমরি থেকে মুছে ফেলতে চান?")
            .setPositiveButton("হ্যাঁ", (dialog, which) -> {
                if (item.filePath != null) {
                    File f = new File(item.filePath);
                    if (f.exists()) f.delete();
                }
                int pos = downloadList.indexOf(item);
                if (pos != -1) {
                    downloadList.remove(pos);
                    downloadAdapter.notifyItemRemoved(pos);
                }
                updateEmptyDownloadState();
                Toast.makeText(this, "ফাইলটি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("না", null)
            .show();
    }

    private void togglePause(DownloadItem item) {
        item.isPaused = !item.isPaused;
        if (!item.isPaused && (item.downloadThread == null || !item.downloadThread.isAlive())) {
            startCustomDownload(item);
        }
        downloadAdapter.notifyItemChanged(downloadList.indexOf(item));
        updateNotification(item, NotificationManagerCompat.from(this));
    }

    private void openVideoPlayer(String path) {
        videoPlayerOverlay.setVisibility(View.VISIBLE);
        topToolbar.setVisibility(View.GONE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        
        // Enable Immersive Mode
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | 
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | 
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        
        txtVideoTitle.setText(new File(path).getName());
        videoView.setVideoPath(path);
        videoView.setOnPreparedListener(mp -> {
            videoSeekBar.setMax(videoView.getDuration());
            videoView.start();
            btnVideoPlayPauseCenter.setImageResource(R.drawable.ic_pause);
            showVideoControls();
            updateSeekBar();
        });

        videoView.setOnCompletionListener(mp -> {
            btnVideoPlayPauseCenter.setImageResource(R.drawable.ic_play);
            videoSeekBar.setProgress(0);
            showVideoControls();
        });
        
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void closeVideoPlayer() {
        if (videoView.isPlaying()) videoView.stopPlayback();
        videoPlayerOverlay.setVisibility(View.GONE);
        topToolbar.setVisibility(View.VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        
        // Disable Immersive Mode
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        
        videoHandler.removeCallbacks(updateSeekBarRunnable);
        videoHandler.removeCallbacks(hideControlsRunnable);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        isVideoLocked = false;
        
        // Security: Relock the file if it was playing from vault
        if (vaultTempFile != null && vaultTempFile.exists()) {
            File lockedFile = new File(vaultTempFile.getAbsolutePath() + ".locked");
            vaultTempFile.renameTo(lockedFile);
            vaultTempFile = null;
        }
    }

    private void updateSeekBar() {
        videoHandler.postDelayed(updateSeekBarRunnable, 1000);
    }

    private Runnable updateSeekBarRunnable = new Runnable() {
        @Override
        public void run() {
            if (videoView != null) {
                int current = videoView.getCurrentPosition();
                int total = videoView.getDuration();
                videoSeekBar.setProgress(current);
                txtVideoTime.setText(formatTime(current) + " / " + formatTime(total));
            }
            videoHandler.postDelayed(this, 1000);
        }
    };

    private String formatTime(int ms) {
        int seconds = (ms / 1000) % 60;
        int minutes = (ms / (1000 * 60)) % 60;
        int hours = (ms / (1000 * 60 * 60)) % 24;
        if (hours > 0) return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        return String.format("%02d:%02d", minutes, seconds);
    }

    private boolean isVideoFile(String path) {
        if (path == null) return false;
        String p = path.toLowerCase();
        return p.endsWith(".mp4") || p.endsWith(".mkv") || p.endsWith(".webm") || p.endsWith(".3gp") || p.endsWith(".avi");
    }

    private void showMenu() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View menuView = getLayoutInflater().inflate(R.layout.menu_bottom_sheet, null);
        
        SwitchMaterial switchSecurity = menuView.findViewById(R.id.switchSecurity);
        switchSecurity.setChecked(isSecurityEnabled);
        switchSecurity.setOnCheckedChangeListener((b, isChecked) -> {
            isSecurityEnabled = isChecked;
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_SECURITY, isChecked).apply();
        });

        // Strict Domain Lock Toggle Logic
        SwitchMaterial switchStrictDomain = menuView.findViewById(R.id.switchStrictDomain);
        switchStrictDomain.setChecked(isStrictDomainLockEnabled);
        switchStrictDomain.setOnCheckedChangeListener((b, isChecked) -> {
            isStrictDomainLockEnabled = isChecked;
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_STRICT_DOMAIN, isChecked).apply();
        });

        // Reload Logic
        menuView.findViewById(R.id.menuReload).setOnClickListener(v -> {
            dialog.dismiss();
            if (getCurrentWebView() != null) getCurrentWebView().reload();
        });

        // Copy Link Logic
        menuView.findViewById(R.id.menuCopyLink).setOnClickListener(v -> {
            dialog.dismiss();
            if (getCurrentWebView() != null && getCurrentWebView().getUrl() != null) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Copied Link", getCurrentWebView().getUrl());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "লিংক কপি করা হয়েছে", Toast.LENGTH_SHORT).show();
            }
        });

        menuView.findViewById(R.id.menuHistory).setOnClickListener(v -> { dialog.dismiss(); showHistory(); });
        menuView.findViewById(R.id.menuDownloads).setOnClickListener(v -> { dialog.dismiss(); showDownloads(); });
        menuView.findViewById(R.id.menuClearHistory).setOnClickListener(v -> { dialog.dismiss(); confirmClearHistory(); });
        
        dialog.setContentView(menuView);
        dialog.show();
    }

    private void confirmClearHistory() {
        new MaterialAlertDialogBuilder(this)
            .setTitle("হিস্টরি মুছুন")
            .setMessage("আপনি কি নিশ্চিতভাবে সব ব্রাউজিং হিস্টরি মুছে ফেলতে চান?")
            .setPositiveButton("হ্যাঁ", (d, w) -> {
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().remove(KEY_HISTORY).apply();
                loadHistoryUI();
                if (historyPageOverlay.getVisibility() == View.VISIBLE) showHistory();
            })
            .setNegativeButton("না", null).show();
    }

    private void showDownloads() { downloadPageOverlay.setVisibility(View.VISIBLE); updateEmptyDownloadState(); }
    private void hideDownloads() { downloadPageOverlay.setVisibility(View.GONE); }
    private void updateEmptyDownloadState() { txtEmptyDownloads.setVisibility(downloadList.isEmpty() ? View.VISIBLE : View.GONE); }

    private void showHistory() {
        historyPageOverlay.setVisibility(View.VISIBLE);
        fullHistoryList.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String data = prefs.getString(KEY_HISTORY, "");
        if (!data.isEmpty()) {
            for (String entry : data.split("###")) {
                String[] parts = entry.split("\\|");
                if (parts.length >= 2) fullHistoryList.add(new HistoryItem(parts[0], parts[1]));
            }
        }
        txtEmptyHistory.setVisibility(fullHistoryList.isEmpty() ? View.VISIBLE : View.GONE);
        historyAdapter.notifyDataSetChanged();
    }
    private void hideHistory() { historyPageOverlay.setVisibility(View.GONE); }

    private void loadExistingDownloads() {
        downloadList.clear();
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Permission Browser");
        if (downloadDir.exists()) {
            File[] files = downloadDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.getName().equals(PRIVATE_DIR_NAME)) continue;
                    DownloadItem item = new DownloadItem("", f.getName());
                    item.totalSize = f.length(); item.downloadedSize = f.length();
                    item.progress = 100; item.isCompleted = true; item.filePath = f.getAbsolutePath();
                    downloadList.add(item);
                }
                downloadAdapter.notifyDataSetChanged();
            }
        }
    }

    private class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_download, parent, false));
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            DownloadItem item = downloadList.get(position);
            holder.name.setText(item.fileName);
            holder.progress.setProgress(item.progress);
            holder.size.setText(String.format(Locale.US, "%.2f MB / %.2f MB", item.downloadedSize/1024.0/1024.0, item.totalSize/1024.0/1024.0));
            
            if (item.isCompleted) {
                holder.status.setText("ডাউনলোড সম্পন্ন");
                holder.status.setTextColor(0xFF10b981);
                holder.btnPause.setVisibility(View.GONE);
                holder.btnCancel.setVisibility(View.GONE);
                holder.btnDelete.setVisibility(View.VISIBLE);
                holder.btnLock.setVisibility(View.VISIBLE);
                if (isVideoFile(item.filePath)) {
                    holder.btnPlay.setVisibility(View.VISIBLE);
                } else {
                    holder.btnPlay.setVisibility(View.GONE);
                }
            } else if (item.isFailed) {
                holder.status.setText("ডাউনলোড ব্যর্থ হয়েছে");
                holder.status.setTextColor(0xFFEF4444);
                holder.btnPause.setVisibility(View.GONE);
                holder.btnCancel.setVisibility(View.VISIBLE);
                holder.btnDelete.setVisibility(View.GONE);
                holder.btnPlay.setVisibility(View.GONE);
                holder.btnLock.setVisibility(View.GONE);
            } else {
                holder.status.setText(item.isPaused ? "স্থগিত" : "ডাউনলোড হচ্ছে...");
                holder.status.setTextColor(0xFF94a3b8);
                holder.btnPause.setVisibility(View.VISIBLE);
                holder.btnCancel.setVisibility(View.VISIBLE);
                holder.btnDelete.setVisibility(View.GONE);
                holder.btnPlay.setVisibility(View.GONE);
                holder.btnLock.setVisibility(View.GONE);
                holder.btnPause.setImageResource(item.isPaused ? R.drawable.ic_play : R.drawable.ic_pause);
            }

            holder.btnPause.setOnClickListener(v -> togglePause(item));
            holder.btnCancel.setOnClickListener(v -> cancelDownload(item));
            holder.btnDelete.setOnClickListener(v -> deleteFile(item));
            holder.btnPlay.setOnClickListener(v -> openVideoPlayer(item.filePath));
            holder.btnLock.setOnClickListener(v -> lockFile(item));
        }
        @Override
        public int getItemCount() { return downloadList.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView name, status, size; ProgressBar progress; ImageButton btnPause, btnCancel, btnPlay, btnDelete, btnLock;
            ViewHolder(View v) { 
                super(v); 
                name = v.findViewById(R.id.txtFileName); 
                status = v.findViewById(R.id.txtDownloadStatus); 
                size = v.findViewById(R.id.txtProgressSize);
                progress = v.findViewById(R.id.downloadProgress); 
                btnPause = v.findViewById(R.id.btnPauseResume);
                btnCancel = v.findViewById(R.id.btnCancelDownload);
                btnPlay = v.findViewById(R.id.btnPlayVideo);
                btnDelete = v.findViewById(R.id.btnDeleteFile);
                btnLock = v.findViewById(R.id.btnLockFile);
            }
        }
    }
    
    private class VaultAdapter extends RecyclerView.Adapter<VaultAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_download, parent, false));
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            VaultItem item = vaultList.get(position);
            holder.name.setText(item.fileName);
            holder.progress.setProgress(100);
            holder.size.setText(String.format(Locale.US, "%.2f MB", item.size/1024.0/1024.0));
            holder.status.setText("লক করা ফাইল");
            holder.status.setTextColor(0xFFf59e0b);
            
            holder.btnPause.setVisibility(View.GONE);
            holder.btnCancel.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
            
            // Enable play button for videos in vault
            if (isVideoFile(item.fileName)) {
                holder.btnPlay.setVisibility(View.VISIBLE);
                holder.btnPlay.setOnClickListener(v -> playVaultVideo(item));
            } else {
                holder.btnPlay.setVisibility(View.GONE);
            }
            
            // Reuse lock button as unlock button
            holder.btnLock.setVisibility(View.VISIBLE);
            holder.btnLock.setImageResource(android.R.drawable.ic_menu_upload); // Unlock icon
            holder.btnLock.setOnClickListener(v -> unlockFile(item));
        }
        @Override
        public int getItemCount() { return vaultList.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView name, status, size; ProgressBar progress; ImageButton btnPause, btnCancel, btnPlay, btnDelete, btnLock;
            ViewHolder(View v) { 
                super(v); 
                name = v.findViewById(R.id.txtFileName); 
                status = v.findViewById(R.id.txtDownloadStatus); 
                size = v.findViewById(R.id.txtProgressSize);
                progress = v.findViewById(R.id.downloadProgress); 
                btnPause = v.findViewById(R.id.btnPauseResume);
                btnCancel = v.findViewById(R.id.btnCancelDownload);
                btnPlay = v.findViewById(R.id.btnPlayVideo);
                btnDelete = v.findViewById(R.id.btnDeleteFile);
                btnLock = v.findViewById(R.id.btnLockFile);
            }
        }
    }

    private class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_history, parent, false));
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            HistoryItem item = fullHistoryList.get(position);
            holder.title.setText(item.title);
            holder.url.setText(item.url);
            loadFavicon(item.url, holder.icon);
            holder.itemView.setOnClickListener(v -> { hideHistory(); openUrl(item.url); });
        }
        @Override
        public int getItemCount() { return fullHistoryList.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView title, url; ImageView icon;
            ViewHolder(View v) { super(v); title = v.findViewById(R.id.historyTitle); url = v.findViewById(R.id.historyUrl); icon = v.findViewById(R.id.historyFavicon); }
        }
    }

    // Dynamic Shortcut Adapter
    private class ShortcutAdapter extends RecyclerView.Adapter<ShortcutAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_shortcut, parent, false));
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ShortcutItem item = shortcutList.get(position);
            holder.title.setText(item.title);
            
            String iconUrlToLoad = item.icon_url;
            if (iconUrlToLoad == null || iconUrlToLoad.isEmpty()) {
                try {
                    String host = Uri.parse(item.url).getHost();
                    iconUrlToLoad = "https://www.google.com/s2/favicons?domain=" + host + "&sz=128";
                } catch (Exception e) {
                    iconUrlToLoad = "";
                }
            }
            
            Glide.with(MainActivity.this)
                 .load(iconUrlToLoad)
                 .transform(new CircleCrop())
                 .placeholder(R.drawable.ic_globe)
                 .into(holder.icon);
                 
            holder.itemView.setOnClickListener(v -> openUrl(item.url));
        }
        @Override
        public int getItemCount() { return shortcutList.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView title; ImageView icon;
            ViewHolder(View v) { super(v); title = v.findViewById(R.id.shortcutTitle); icon = v.findViewById(R.id.shortcutIcon); }
        }
    }

    private void loadDynamicShortcuts() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("home_shortcuts");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                shortcutList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    ShortcutItem item = child.getValue(ShortcutItem.class);
                    if (item != null) {
                        item.id = child.getKey();
                        shortcutList.add(item);
                    }
                }
                shortcutAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error if needed
            }
        });
    }

    private void addNewTab(String url) {
        WebView webView = new WebView(this);
        setupWebViewSettings(webView);
        tabList.add(webView);
        switchTab(tabList.size() - 1);
        if (!url.equals("about:blank")) openUrl(url); else showHomePage();
        updateTabCount();
    }

    private void switchTab(int index) {
        currentTabIndex = index;
        webViewContainer.removeAllViews();
        WebView current = tabList.get(index);
        webViewContainer.addView(current);
        if (current.getUrl() == null || current.getUrl().equals("about:blank")) {
            showHomePage();
        } else { 
            showWebView(); 
            updateAddressBar(current.getUrl());
        }
    }

    private void openUrl(String url) {
        if (!isSecurityEnabled) { showWebView(); getCurrentWebView().loadUrl(url); }
        else { showPermissionDialog(url, getCurrentWebView()); }
    }

    private void performSearch(String query) {
        if (query.isEmpty()) return;
        hideKeyboard(urlInput);
        urlInput.clearFocus();
        
        String url = (query.startsWith("http://") || query.startsWith("https://")) ? query :
                     (query.contains(".") && !query.contains(" ")) ? "https://" + query :
                     "https://www.google.com/search?q=" + query;
        openUrl(url);
    }

    private void showPermissionDialog(final String url, final WebView targetWebView) {
        new MaterialAlertDialogBuilder(this)
            .setTitle("নিরাপত্তা অনুমতি")
            .setMessage("আপনি কি এই লিংকে প্রবেশ করতে চান?\n\n" + url)
            .setCancelable(false)
            .setPositiveButton("হ্যাঁ", (dialog, which) -> {
                lastApprovedUrl = url;
                showWebView();
                targetWebView.loadUrl(url);
            })
            .setNegativeButton("না", (dialog, which) -> {
                if (targetWebView.getUrl() == null || targetWebView.getUrl().equals("about:blank")) showHomePage();
            }).show();
    }

    private void updateAddressBar(String url) {
        if (url == null || url.equals("about:blank")) {
            urlInput.setText("");
            securityIcon.setImageResource(R.drawable.ic_search);
            securityIcon.setColorFilter(0xFF94a3b8); // Gray
        } else {
            urlInput.setText(url);
            if (url.startsWith("https://")) {
                securityIcon.setImageResource(R.drawable.ic_security);
                securityIcon.setColorFilter(0xFF10b981); // Green
            } else {
                securityIcon.setImageResource(android.R.drawable.ic_dialog_alert);
                securityIcon.setColorFilter(0xFFF59E0B); // Orange/Warning
            }
        }
    }

    // Helper method to check if two URLs belong to the same domain
    private boolean isSameDomain(String currentUrl, String targetUrl) {
        if (currentUrl == null || targetUrl == null) return false;
        try {
            String currentHost = Uri.parse(currentUrl).getHost();
            String targetHost = Uri.parse(targetUrl).getHost();
            if (currentHost == null || targetHost == null) return false;
            
            // Remove "www." for comparison
            currentHost = currentHost.replaceFirst("^www\\.", "");
            targetHost = targetHost.replaceFirst("^www\\.", "");
            
            // Check if target ends with current host or vice versa (handles subdomains)
            return targetHost.equals(currentHost) || targetHost.endsWith("." + currentHost) || currentHost.endsWith("." + targetHost);
        } catch (Exception e) {
            return false;
        }
    }

    private class GatekeeperClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            String targetUrl = request.getUrl().toString();
            String currentUrl = view.getUrl();
            
            if (targetUrl.equals("about:blank")) return false;
            
            // Strict Domain Lock Logic: Silently cancel if domains don't match
            if (isStrictDomainLockEnabled && currentUrl != null && !currentUrl.equals("about:blank")) {
                if (!isSameDomain(currentUrl, targetUrl)) {
                    return true; // Return true to cancel loading silently
                }
            }
            
            if (!isSecurityEnabled) return false;
            if (targetUrl.equals(lastApprovedUrl)) { lastApprovedUrl = ""; return false; }
            showPermissionDialog(targetUrl, view);
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            if (view == getCurrentWebView()) {
                updateAddressBar(url);
                urlInput.clearFocus();
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (view == getCurrentWebView()) {
                updateAddressBar(url);
                urlInput.clearFocus();
            }
            if (url != null && !url.equals("about:blank")) {
                saveToHistory(view.getTitle(), url);
            }
        }
    }

    private void saveToHistory(String title, String url) {
        if (title == null || title.isEmpty()) title = url;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String historyStr = prefs.getString(KEY_HISTORY, "");
        List<String> list = new ArrayList<>(Arrays.asList(historyStr.split("###")));
        
        String entry = title + "|" + url;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).contains("|" + url)) {
                list.remove(i);
                break;
            }
        }
        
        list.add(0, entry);
        if (list.size() > 500) list = list.subList(0, 500);
        
        StringBuilder sb = new StringBuilder();
        for (String s : list) if (!s.isEmpty()) sb.append(s).append("###");
        prefs.edit().putString(KEY_HISTORY, sb.toString()).apply();
        loadHistoryUI();
    }

    private void loadHistoryUI() {
        historyContainer.removeAllViews();
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String historyStr = prefs.getString(KEY_HISTORY, "");
        if (historyStr.isEmpty()) return;

        String[] entries = historyStr.split("###");
        int count = 0;
        for (String entry : entries) {
            if (count >= 5) break; // Show max 5 on home screen
            String[] parts = entry.split("\\|");
            if (parts.length >= 2) {
                String title = parts[0];
                String url = parts[1];

                View view = LayoutInflater.from(this).inflate(R.layout.item_history, historyContainer, false);
                TextView tvTitle = view.findViewById(R.id.historyTitle);
                TextView tvUrl = view.findViewById(R.id.historyUrl);
                ImageView icon = view.findViewById(R.id.historyFavicon);

                tvTitle.setText(title);
                tvUrl.setText(url);
                loadFavicon(url, icon);

                view.setOnClickListener(v -> openUrl(url));
                historyContainer.addView(view);
                count++;
            }
        }
    }

    private void loadFavicon(String url, ImageView imageView) {
        try {
            String host = Uri.parse(url).getHost();
            String faviconUrl = "https://www.google.com/s2/favicons?domain=" + host + "&sz=128";
            Glide.with(this).load(faviconUrl).transform(new CircleCrop()).placeholder(R.drawable.ic_globe).into(imageView);
        } catch (Exception e) { imageView.setImageResource(R.drawable.ic_globe); }
    }

    private void showTabSwitcher() { topToolbar.setVisibility(View.GONE); tabSwitcherOverlay.setVisibility(View.VISIBLE); tabRecyclerView.setAdapter(new TabAdapter()); }
    private void hideTabSwitcher() { topToolbar.setVisibility(View.VISIBLE); tabSwitcherOverlay.setVisibility(View.GONE); }
    private void showHomePage() { 
        topToolbar.setVisibility(View.VISIBLE); 
        webViewContainer.setVisibility(View.GONE); 
        homeLayout.setVisibility(View.VISIBLE); 
        updateAddressBar("about:blank");
        loadHistoryUI(); 
    }
    private void showWebView() { topToolbar.setVisibility(View.VISIBLE); homeLayout.setVisibility(View.GONE); webViewContainer.setVisibility(View.VISIBLE); }
    private WebView getCurrentWebView() { return tabList.get(currentTabIndex); }
    private void updateTabCount() { tabCountText.setText(String.valueOf(tabList.size())); }

    // App Update Checker Logic
    private void checkAppUpdate() {
        DatabaseReference updateRef = FirebaseDatabase.getInstance().getReference("app_update");
        updateRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Long versionCode = snapshot.child("version_code").getValue(Long.class);
                    String updateUrl = snapshot.child("download_url").getValue(String.class);
                    String updateMessage = snapshot.child("message").getValue(String.class);
                    
                    int currentVersionCode = 0;
                    try {
                        currentVersionCode = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }

                    // Check if remote version is greater than current app version
                    if (versionCode != null && versionCode > currentVersionCode) {
                        showUpdateDialog(updateMessage, updateUrl);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
            }
        });
    }

    private void showUpdateDialog(String message, String url) {
        if (isFinishing()) return;
        new MaterialAlertDialogBuilder(this)
            .setTitle("নতুন আপডেট উপলব্ধ")
            .setMessage(message != null ? message : "অ্যাপটির নতুন ভার্সন এসেছে। দয়া করে আপডেট করুন।")
            .setCancelable(false)
            .setPositiveButton("আপডেট করুন", (dialog, which) -> {
                if (url != null && !url.isEmpty()) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                }
            })
            .setNegativeButton("পরে", null)
            .show();
    }

    @Override
    public void onBackPressed() {
        if (pinEntryOverlay.getVisibility() == View.VISIBLE) {
            pinEntryOverlay.setVisibility(View.GONE);
            currentPinInput = "";
        } else if (privateVaultOverlay.getVisibility() == View.VISIBLE) {
            privateVaultOverlay.setVisibility(View.GONE);
        } else if (videoPlayerOverlay.getVisibility() == View.VISIBLE) {
            if (isVideoLocked) {
                Toast.makeText(this, "প্লেয়ার আনলক করুন", Toast.LENGTH_SHORT).show();
            } else {
                closeVideoPlayer();
            }
        } else if (fullscreenContainer.getVisibility() == View.VISIBLE) {
            WebChromeClient client = getCurrentWebView().getWebChromeClient();
            if (client != null) client.onHideCustomView();
        } else if (historyPageOverlay.getVisibility() == View.VISIBLE) {
            hideHistory();
        } else if (downloadPageOverlay.getVisibility() == View.VISIBLE) {
            hideDownloads();
        } else if (tabSwitcherOverlay.getVisibility() == View.VISIBLE) {
            hideTabSwitcher();
        } else if (webViewContainer.getVisibility() == View.VISIBLE) {
            if (getCurrentWebView().canGoBack()) getCurrentWebView().goBack();
            else showHomePage();
        } else {
            super.onBackPressed();
        }
    }

    private class TabAdapter extends RecyclerView.Adapter<TabAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tab, parent, false));
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            WebView wv = tabList.get(position);
            holder.title.setText(wv.getUrl() == null || wv.getUrl().equals("about:blank") ? "New Tab" : wv.getTitle());
            holder.itemView.setOnClickListener(v -> { switchTab(position); hideTabSwitcher(); });
            holder.close.setOnClickListener(v -> {
                if (tabList.size() > 1) {
                    tabList.remove(position);
                    if (currentTabIndex >= tabList.size()) currentTabIndex = tabList.size() - 1;
                    notifyDataSetChanged(); updateTabCount();
                }
            });
        }
        @Override
        public int getItemCount() { return tabList.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView title; ImageButton close;
            ViewHolder(View v) { super(v); title = v.findViewById(R.id.tabTitle); close = v.findViewById(R.id.closeTab); }
        }
    }
}