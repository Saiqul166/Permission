# ZB Movie Android App — CodeAssist/AIDE Compatible (FCM সহ)

## যা আছে এই version এ
- ✅ **CodeAssist এ open হবে** — AndroidManifest এ `package` attribute আছে
- ✅ **AndroidX নেই** — Support Library 28 ব্যবহৃত
- ✅ **Firebase AAR ফাইল `app/libs/` এ pre-bundled** — Maven download না করেও কাজ করবে
- ✅ Firebase Messaging 17.6.0 (legacy non-AndroidX)
- ✅ MyFirebaseMessagingService — app বন্ধ থাকলেও notification আসবে
- ✅ Topic "all" subscribe — admin সবাইকে এক ক্লিকে পাঠাতে পারবে
- ✅ POST_NOTIFICATIONS permission (Android 13+)
- ✅ Notification ক্লিক করলে app খোলে, click_url থাকলে load হয়

## Build instructions

### CodeAssist এ:
1. ZIP unzip করুন
2. CodeAssist এ **Open Project** → "ZB Movie" folder select করুন
3. Build → Run

### AIDE তে:
1. ZIP unzip করে SD card এ রাখুন
2. AIDE তে folder open করুন
3. Run চাপুন

## Files
- `app/google-services.json` — Firebase config (already included)
- `app/libs/*.aar` — সব Firebase + Play Services dependencies
- `app/src/main/java/com/zbmovie/app/` — সব Java source
