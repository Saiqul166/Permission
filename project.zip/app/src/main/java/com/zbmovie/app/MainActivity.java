package com.zbmovie.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {

    private static final String TAG = "ZBMovie";
    private static final String SITE_URL = "https://hobo-hobo-web.lovable.app/";
    // Hosts that are considered "internal" (open in main webview, NOT mini browser)
    private static final String[] INTERNAL_HOSTS = new String[] {
            "hobo-hobo-web.lovable.app",
            "lovableproject.com",
            "lovable.app"
    };
    private static final int REQ_NOTIF_PERM = 1001;

    private WebView webView;
    private ProgressBar progressBar;

    // Mini browser
    private RelativeLayout miniBrowserContainer;
    private WebView miniWebView;
    private ProgressBar miniProgressBar;
    private TextView miniBrowserUrl;
    private ImageButton miniBrowserClose;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.webView);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        miniBrowserContainer = (RelativeLayout) findViewById(R.id.miniBrowserContainer);
        miniWebView = (WebView) findViewById(R.id.miniWebView);
        miniProgressBar = (ProgressBar) findViewById(R.id.miniProgressBar);
        miniBrowserUrl = (TextView) findViewById(R.id.miniBrowserUrl);
        miniBrowserClose = (ImageButton) findViewById(R.id.miniBrowserClose);

        configureWebSettings(webView);
        configureWebSettings(miniWebView);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(miniWebView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (isExternalUrl(url)) {
                    openMiniBrowser(url);
                    return true;
                }
                view.loadUrl(url);
                return true;
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    request.setMimeType(mimetype);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setDescription("Downloading...");
                    request.setTitle(fileName);
                    request.allowScanningByMediaScanner();
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(request);
                        Toast.makeText(getApplicationContext(), "Downloading: " + fileName, Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Download failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Mini browser handlers
        miniWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                miniBrowserUrl.setText(url);
                view.loadUrl(url);
                return true;
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                miniProgressBar.setVisibility(View.VISIBLE);
                miniBrowserUrl.setText(url);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                miniProgressBar.setVisibility(View.GONE);
            }
        });
        miniWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                miniProgressBar.setProgress(newProgress);
                miniProgressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        miniBrowserClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeMiniBrowser();
            }
        });

        String startUrl = SITE_URL;
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("click_url")) {
            String cu = intent.getStringExtra("click_url");
            if (cu != null && !cu.isEmpty()) startUrl = cu;
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(startUrl);
        }

        requestNotificationPermissionIfNeeded();
        fetchAndRegisterFcmToken();

        try {
            FirebaseMessaging.getInstance().subscribeToTopic("all");
        } catch (Exception e) {
            Log.w(TAG, "subscribe failed: " + e.getMessage());
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebSettings(WebView wv) {
        WebSettings settings = wv.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
    }

    private boolean isExternalUrl(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            if (scheme == null) return false;
            if (!scheme.equals("http") && !scheme.equals("https")) return false;
            String host = uri.getHost();
            if (host == null) return false;
            for (String h : INTERNAL_HOSTS) {
                if (host.equals(h) || host.endsWith("." + h)) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void openMiniBrowser(String url) {
        miniBrowserUrl.setText(url);
        // Set height to half of the screen
        int halfHeight = getResources().getDisplayMetrics().heightPixels / 2;
        android.view.ViewGroup.LayoutParams lp = miniBrowserContainer.getLayoutParams();
        lp.height = halfHeight;
        miniBrowserContainer.setLayoutParams(lp);
        miniBrowserContainer.setVisibility(View.VISIBLE);
        miniWebView.loadUrl(url);
    }

    private void closeMiniBrowser() {
        miniBrowserContainer.setVisibility(View.GONE);
        try {
            miniWebView.stopLoading();
            miniWebView.loadUrl("about:blank");
        } catch (Exception ignored) {}
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.hasExtra("click_url")) {
            String cu = intent.getStringExtra("click_url");
            if (cu != null && !cu.isEmpty() && webView != null) {
                webView.loadUrl(cu);
            }
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF_PERM);
            }
        }
    }

    private void fetchAndRegisterFcmToken() {
        try {
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(Task<InstanceIdResult> task) {
                            if (!task.isSuccessful() || task.getResult() == null) {
                                Log.w(TAG, "FCM token failed", task.getException());
                                return;
                            }
                            String token = task.getResult().getToken();
                            Log.d(TAG, "FCM token: " + token);
                            TokenRegistrationHelper.registerToken(getApplicationContext(), token);
                        }
                    });
        } catch (Exception e) {
            Log.e(TAG, "FCM init error: " + e.getMessage());
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // If mini browser open, close it first
            if (miniBrowserContainer != null && miniBrowserContainer.getVisibility() == View.VISIBLE) {
                if (miniWebView.canGoBack()) {
                    miniWebView.goBack();
                } else {
                    closeMiniBrowser();
                }
                return true;
            }
            if (webView.canGoBack()) {
                webView.goBack();
                return true;
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Exit ZB Movie")
                        .setMessage("Are you sure you want to exit?")
                        .setPositiveButton("Yes", new android.content.DialogInterface.OnClickListener() {
                            public void onClick(android.content.DialogInterface d, int w) { finish(); }
                        })
                        .setNegativeButton("No", null)
                        .show();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
