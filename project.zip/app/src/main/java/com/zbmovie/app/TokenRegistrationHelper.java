package com.zbmovie.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class TokenRegistrationHelper {

    private static final String TAG = "ZBToken";
    private static final String PREFS = "zb_fcm_prefs";
    private static final String KEY_TOKEN = "registered_token";

    private static final String ENDPOINT = "https://zejjodvvosqvjytqzauz.supabase.co/functions/v1/register-device";
    private static final String ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InplampvZHZ2b3Nxdmp5dHF6YXV6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5MjY4MzUsImV4cCI6MjA3NTUwMjgzNX0.RO1J9Gbnxzo1q6Ddt411bXQ-8w88v9MBTl15BwVfR08";

    public static void registerToken(final Context ctx, final String token) {
        if (token == null || token.isEmpty()) return;

        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String saved = prefs.getString(KEY_TOKEN, null);
        if (token.equals(saved)) {
            Log.d(TAG, "Token already registered");
            return;
        }

        new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection conn = null;
                try {
                    JSONObject deviceInfo = new JSONObject();
                    deviceInfo.put("manufacturer", Build.MANUFACTURER);
                    deviceInfo.put("model", Build.MODEL);
                    deviceInfo.put("os", "Android " + Build.VERSION.RELEASE);
                    deviceInfo.put("app_version", "1.3");

                    JSONObject body = new JSONObject();
                    body.put("fcm_token", token);
                    body.put("device_info", deviceInfo);

                    URL url = new URL(ENDPOINT);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("apikey", ANON_KEY);
                    conn.setRequestProperty("Authorization", "Bearer " + ANON_KEY);
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(15000);

                    OutputStream os = conn.getOutputStream();
                    os.write(body.toString().getBytes("UTF-8"));
                    os.flush();
                    os.close();

                    int code = conn.getResponseCode();
                    Log.d(TAG, "Register response: " + code);
                    if (code >= 200 && code < 300) {
                        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                .edit().putString(KEY_TOKEN, token).apply();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Register failed: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}
