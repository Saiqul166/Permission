package com.zbchatff.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView

class ChatAdapter(private val chats: List<Chat>, private val onChatClick: (Chat) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val VIEW_TYPE_ARCHIVED = 0
    private val VIEW_TYPE_NORMAL = 1

    override fun getItemViewType(position: Int): Int {
        return if (chats[position].isArchived) VIEW_TYPE_ARCHIVED else VIEW_TYPE_NORMAL
    }

    class ArchivedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // No binding needed, static texts
    }

    class ChatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val avatar: ImageView = itemView.findViewById(R.id.chat_avatar)
        val name: TextView = itemView.findViewById(R.id.chat_name)
        val message: TextView = itemView.findViewById(R.id.chat_message)
        val time: TextView = itemView.findViewById(R.id.chat_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == VIEW_TYPE_ARCHIVED) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_archived, parent, false)
            return ArchivedViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
            return ChatViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val chat = chats[position]
        
        holder.itemView.setOnClickListener {
            onChatClick(chat)
        }
        
        if (holder is ChatViewHolder) {
            holder.name.text = chat.name
            holder.time.text = chat.time
            
            // Set Avatar
            if (chat.name == "Meta AI") {
                holder.avatar.setImageResource(R.drawable.ic_meta_ai_ring)
                holder.avatar.setBackgroundColor(android.graphics.Color.TRANSPARENT)
            } else if (chat.name == "WhatsApp") {
                holder.avatar.setImageResource(R.mipmap.ic_launcher_round)
            } else {
                holder.avatar.setImageResource(android.R.drawable.ic_menu_myplaces) // Just a placeholder body icon
            }

            // Set message with optional icon prefixes
            val messageText = buildString {
                if (chat.showCallIcon) append("📞 ")
                if (chat.showPhotoIcon) append("📷 ")
                append(chat.message)
            }
            holder.message.text = messageText
        }
    }

    override fun getItemCount(): Int = chats.size
}
