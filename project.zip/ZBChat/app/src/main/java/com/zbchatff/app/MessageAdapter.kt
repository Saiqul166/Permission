package com.zbchatff.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class MessageAdapter(private val messages: List<Message>) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    private val currentUserId = FirebaseAuth.getInstance().currentUser?.uid

    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messageContainer: LinearLayout = itemView.findViewById(R.id.messageContainer)
        val tvMessageText: TextView = itemView.findViewById(R.id.tvMessageText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]
        holder.tvMessageText.text = message.text

        val layoutParams = holder.messageContainer.layoutParams as LinearLayout.LayoutParams
        val bgDrawable = GradientDrawable()
        bgDrawable.cornerRadius = 24f

        if (message.senderId == currentUserId) {
            // Sent message
            layoutParams.gravity = android.view.Gravity.END
            bgDrawable.setColor(Color.parseColor("#005C4B")) // WhatsApp dark mode sent message color
        } else {
            // Received message
            layoutParams.gravity = android.view.Gravity.START
            bgDrawable.setColor(Color.parseColor("#202C33")) // WhatsApp dark mode received message color
        }
        
        holder.messageContainer.layoutParams = layoutParams
        holder.messageContainer.background = bgDrawable
    }

    override fun getItemCount(): Int = messages.size
}
