package com.zbchatff.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RequestsActivity : AppCompatActivity() {
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var rvRequests: RecyclerView
    private lateinit var adapter: RequestAdapter
    private val requestsList = mutableListOf<FriendRequest>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_requests)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val toolbar = findViewById<Toolbar>(R.id.toolbarRequests)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Friend Requests"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        rvRequests = findViewById(R.id.rvRequests)
        rvRequests.layoutManager = LinearLayoutManager(this)
        adapter = RequestAdapter(requestsList, auth.currentUser!!.uid)
        rvRequests.adapter = adapter

        loadRequests()
    }

    private fun loadRequests() {
        db.collection("friend_requests")
            .whereEqualTo("receiverId", auth.currentUser!!.uid)
            .whereEqualTo("status", "pending")
            .addSnapshotListener { snapshot, e ->
                if (e != null) return@addSnapshotListener
                requestsList.clear()
                if (snapshot != null) {
                    for (doc in snapshot.documents) {
                        val req = doc.toObject(FriendRequest::class.java)
                        if (req != null) {
                            req.id = doc.id
                            requestsList.add(req)
                        }
                    }
                }
                adapter.notifyDataSetChanged()
            }
    }
}
