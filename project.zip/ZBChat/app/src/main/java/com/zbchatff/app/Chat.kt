package com.zbchatff.app

data class Chat(
    val id: Int,
    val name: String,
    val message: String,
    val time: String,
    val isArchived: Boolean = false,
    val showPhotoIcon: Boolean = false,
    val showCallIcon: Boolean = false
)
