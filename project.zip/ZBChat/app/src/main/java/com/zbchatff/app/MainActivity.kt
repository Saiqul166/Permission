package com.zbchatff.app

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var adapter: ConversationAdapter
    private val conversations = mutableListOf<Conversation>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewChats)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = ConversationAdapter(conversations) { conversation ->
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("chatId", conversation.id)
            intent.putExtra("chatName", conversation.otherUsername)
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        val fabMain = findViewById<FloatingActionButton>(R.id.fab_main)
        val fabSecondary = findViewById<FloatingActionButton>(R.id.fab_secondary)
        
        fabMain.setOnClickListener {
            startActivity(Intent(this, NewChatActivity::class.java))
        }

        val bottomNavigationView = findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_chats -> {
                    recyclerView.visibility = android.view.View.VISIBLE
                    fabMain.visibility = android.view.View.VISIBLE
                    fabSecondary.visibility = android.view.View.VISIBLE
                    fabMain.setImageResource(R.drawable.ic_add_chat)
                    true
                }
                R.id.nav_updates -> {
                    recyclerView.visibility = android.view.View.GONE
                    fabMain.visibility = android.view.View.VISIBLE
                    fabSecondary.visibility = android.view.View.VISIBLE
                    fabMain.setImageResource(R.drawable.ic_camera)
                    Toast.makeText(this, "Updates tab selected", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_communities -> {
                    recyclerView.visibility = android.view.View.GONE
                    fabMain.visibility = android.view.View.GONE
                    fabSecondary.visibility = android.view.View.GONE
                    Toast.makeText(this, "Communities tab selected", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_calls -> {
                    recyclerView.visibility = android.view.View.GONE
                    fabMain.visibility = android.view.View.VISIBLE
                    fabSecondary.visibility = android.view.View.GONE
                    fabMain.setImageResource(R.drawable.ic_calls)
                    Toast.makeText(this, "Calls tab selected", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }

        loadConversations()
        requestNotificationPermission()
        updateFcmToken()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun updateFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val token = task.result
                auth.currentUser?.uid?.let { uid ->
                    db.collection("users").document(uid).update("fcmToken", token)
                }
            }
        }
    }

    private fun loadConversations() {
        val currentUserUid = auth.currentUser?.uid ?: return
        db.collection("chats")
            .whereArrayContains("uids", currentUserUid)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(this, "Listen failed.", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    conversations.clear()
                    for (doc in snapshot.documents) {
                        val conv = doc.toObject(Conversation::class.java)
                        if (conv != null) {
                            conv.id = doc.id
                            // Find other username
                            val otherUsername = conv.participants.find { !it.contains(currentUserUid, ignoreCase = true) } ?: "Unknown"
                            // If participants were stored as string JSON, etc.
                            // Let's assume participants array stores "uid:username"
                            // e.g., "uid1:Alice" and "uid2:Bob"
                            
                            val me = conv.participants.find { it.startsWith("$currentUserUid:") }
                            val other = conv.participants.find { !it.startsWith("$currentUserUid:") }
                            
                            conv.otherUsername = other?.substringAfter(":") ?: "User"
                            
                            conversations.add(conv)
                        }
                    }
                    conversations.sortByDescending { it.timestamp }
                    adapter.notifyDataSetChanged()
                }
            }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Camera").setIcon(R.drawable.ic_camera).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        menu.add(0, 3, 0, "New group")
        menu.add(0, 4, 0, "Broadcast lists")
        menu.add(0, 5, 0, "Linked devices")
        menu.add(0, 6, 0, "Starred")
        menu.add(0, 7, 0, "Read all")
        menu.add(0, 8, 0, "Settings")
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            8 -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}