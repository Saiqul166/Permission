package com.zbchatff.app

data class Message(
    val senderId: String = "",
    val text: String = "",
    val timestamp: Long = 0
)
