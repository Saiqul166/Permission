package com.zbchatff.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ConversationAdapter(
    private val conversations: List<Conversation>,
    private val onChatClick: (Conversation) -> Unit
) : RecyclerView.Adapter<ConversationAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val avatar: ImageView = itemView.findViewById(R.id.chat_avatar)
        val name: TextView = itemView.findViewById(R.id.chat_name)
        val message: TextView = itemView.findViewById(R.id.chat_message)
        val time: TextView = itemView.findViewById(R.id.chat_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val conv = conversations[position]
        
        holder.itemView.setOnClickListener {
            onChatClick(conv)
        }
        
        holder.name.text = conv.otherUsername
        holder.message.text = conv.lastMessage
        holder.avatar.setImageResource(android.R.drawable.ic_menu_myplaces)
        
        if (conv.timestamp > 0) {
            val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
            holder.time.text = sdf.format(Date(conv.timestamp))
        } else {
            holder.time.text = ""
        }
    }

    override fun getItemCount(): Int = conversations.size
}
