package com.zbchatff.app

import com.google.firebase.firestore.Exclude

data class FriendRequest(
    @get:Exclude var id: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val senderUsername: String = "",
    val status: String = "pending",
    val timestamp: Long = 0
)
