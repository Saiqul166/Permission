package com.zbchatff.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class ChatApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
