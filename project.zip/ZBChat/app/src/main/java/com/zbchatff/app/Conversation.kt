package com.zbchatff.app

import com.google.firebase.firestore.Exclude

data class Conversation(
    @get:Exclude var id: String = "",
    val participants: List<String> = emptyList(),
    val uids: List<String> = emptyList(),
    var lastMessage: String = "",
    var timestamp: Long = 0,
    @get:Exclude var otherUsername: String = ""
)
