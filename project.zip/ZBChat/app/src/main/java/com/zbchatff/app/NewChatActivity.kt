package com.zbchatff.app

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class NewChatActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var etSearch: EditText
    private lateinit var rvUsers: RecyclerView
    private lateinit var llRequests: LinearLayout
    private lateinit var tvRequestCount: TextView
    private lateinit var adapter: UserAdapter
    private val usersList = mutableListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_chat)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val toolbar = findViewById<Toolbar>(R.id.toolbarNewChat)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "New chat"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        etSearch = findViewById(R.id.etSearch)
        rvUsers = findViewById(R.id.rvUsers)
        llRequests = findViewById(R.id.llRequests)
        tvRequestCount = findViewById(R.id.tvRequestCount)

        rvUsers.layoutManager = LinearLayoutManager(this)
        adapter = UserAdapter(usersList, auth.currentUser!!.uid)
        rvUsers.adapter = adapter

        llRequests.setOnClickListener {
            startActivity(Intent(this, RequestsActivity::class.java))
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterUsers(s.toString().trim())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        loadRequestCount()
    }

    private fun loadRequestCount() {
        db.collection("friend_requests")
            .whereEqualTo("receiverId", auth.currentUser!!.uid)
            .whereEqualTo("status", "pending")
            .addSnapshotListener { snapshot, e ->
                if (e != null) return@addSnapshotListener
                val count = snapshot?.size() ?: 0
                if (count > 0) {
                    tvRequestCount.visibility = View.VISIBLE
                    tvRequestCount.text = count.toString()
                } else {
                    tvRequestCount.visibility = View.GONE
                }
            }
    }

    private fun filterUsers(query: String) {
        if (query.isEmpty()) {
            usersList.clear()
            adapter.notifyDataSetChanged()
            return
        }
        
        val lowerQuery = query.lowercase()
        db.collection("users")
            .whereGreaterThanOrEqualTo("searchName", lowerQuery)
            .whereLessThanOrEqualTo("searchName", lowerQuery + "\uf8ff")
            .get()
            .addOnSuccessListener { snapshot ->
                usersList.clear()
                for (doc in snapshot.documents) {
                    val user = doc.toObject(User::class.java)
                    if (user != null) {
                        val mappedUser = user.copy(uid = doc.id)
                        if (mappedUser.uid != auth.currentUser!!.uid) {
                            usersList.add(mappedUser)
                        }
                    }
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                android.widget.Toast.makeText(this, "Search error: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
    }
}
