package com.zbchatff.app

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class UserAdapter(private val users: List<User>, private val currentUserId: String) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivAvatar: ImageView = view.findViewById(R.id.ivAvatar)
        val tvUsername: TextView = view.findViewById(R.id.tvUsername)
        val btnAction: Button = view.findViewById(R.id.btnAction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user_search, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = users[position]
        holder.tvUsername.text = user.username
        
        val db = FirebaseFirestore.getInstance()
        
        holder.btnAction.text = "Loading"
        holder.btnAction.isEnabled = false
        
        db.collection("chats")
            .whereArrayContains("uids", currentUserId)
            .get()
            .addOnSuccessListener { snap ->
                var isChatExists = false
                var existingChatId: String? = null
                for (doc in snap.documents) {
                    val uids = doc.get("uids") as? List<String>
                    if (uids != null && uids.contains(user.uid)) {
                        isChatExists = true
                        existingChatId = doc.id
                        break
                    }
                }
                
                if (isChatExists) {
                    holder.btnAction.text = "Message"
                    holder.btnAction.isEnabled = true
                    holder.btnAction.setBackgroundColor(Color.parseColor("#128C7E"))
                    holder.btnAction.setOnClickListener {
                        val intent = Intent(holder.itemView.context, ChatActivity::class.java)
                        intent.putExtra("chatId", existingChatId)
                        intent.putExtra("chatName", user.username)
                        holder.itemView.context.startActivity(intent)
                    }
                } else {
                    db.collection("friend_requests")
                        .whereEqualTo("senderId", currentUserId)
                        .whereEqualTo("receiverId", user.uid)
                        .get()
                        .addOnSuccessListener { reqSnap ->
                            if (!reqSnap.isEmpty) {
                                holder.btnAction.text = "Requested"
                                holder.btnAction.isEnabled = false
                                holder.btnAction.setBackgroundColor(Color.GRAY)
                            } else {
                                holder.btnAction.text = "Add"
                                holder.btnAction.isEnabled = true
                                holder.btnAction.setBackgroundColor(Color.parseColor("#00A884"))
                                holder.btnAction.setOnClickListener {
                                    sendRequest(holder, user, db)
                                }
                            }
                        }
                }
            }
    }

    private fun sendRequest(holder: ViewHolder, targetUser: User, db: FirebaseFirestore) {
        holder.btnAction.isEnabled = false
        db.collection("users").document(currentUserId).get().addOnSuccessListener { myDoc ->
            val myUsername = myDoc.getString("username") ?: "User"
            val req = hashMapOf(
                "senderId" to currentUserId,
                "receiverId" to targetUser.uid,
                "senderUsername" to myUsername,
                "status" to "pending",
                "timestamp" to System.currentTimeMillis()
            )
            db.collection("friend_requests").add(req)
                .addOnSuccessListener {
                    holder.btnAction.text = "Requested"
                    holder.btnAction.setBackgroundColor(Color.GRAY)
                    Toast.makeText(holder.itemView.context, "Request sent to ${targetUser.username}", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    holder.btnAction.isEnabled = true
                }
        }
    }

    override fun getItemCount() = users.size
}
