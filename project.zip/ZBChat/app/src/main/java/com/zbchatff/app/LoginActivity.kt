package com.zbchatff.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()

        // Check if user is already logged in
        if (auth.currentUser != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            progressBar.visibility = View.VISIBLE
            btnLogin.isEnabled = false

            // Try login first
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    } else {
                        // If login fails, try register
                        auth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(this) { regTask ->
                                progressBar.visibility = View.GONE
                                btnLogin.isEnabled = true
                                if (regTask.isSuccessful) {
                                    val user = auth.currentUser
                                    val username = "user_" + System.currentTimeMillis().toString().takeLast(6)
                                    val userMap = hashMapOf(
                                        "uid" to user!!.uid,
                                        "email" to user.email,
                                        "username" to username,
                                        "searchName" to username.lowercase(),
                                        "fcmToken" to ""
                                    )
                                    com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                        .collection("users").document(user.uid)
                                        .set(userMap)
                                        .addOnCompleteListener {
                                            startActivity(Intent(this, MainActivity::class.java))
                                            finish()
                                        }
                                } else {
                                    Toast.makeText(
                                        this,
                                        "Auth failed: ${regTask.exception?.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                    }
                }
        }
    }
}
