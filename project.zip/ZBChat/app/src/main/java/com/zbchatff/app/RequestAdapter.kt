package com.zbchatff.app

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class RequestAdapter(private val requests: List<FriendRequest>, private val currentUserId: String) : RecyclerView.Adapter<RequestAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivAvatar: ImageView = view.findViewById(R.id.ivAvatar)
        val tvUsername: TextView = view.findViewById(R.id.tvUsername)
        val btnAction: Button = view.findViewById(R.id.btnAction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user_search, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val req = requests[position]
        holder.tvUsername.text = req.senderUsername
        holder.btnAction.text = "Accept"
        holder.btnAction.setBackgroundColor(Color.parseColor("#00A884"))
        
        val db = FirebaseFirestore.getInstance()
        
        holder.btnAction.setOnClickListener {
            holder.btnAction.isEnabled = false
            db.collection("users").document(currentUserId).get().addOnSuccessListener { myDoc ->
                val myUsername = myDoc.getString("username") ?: "User"
                
                val newChat = hashMapOf(
                    "uids" to listOf(currentUserId, req.senderId),
                    "participants" to listOf("$currentUserId:$myUsername", "${req.senderId}:${req.senderUsername}"),
                    "lastMessage" to "Say hi!",
                    "timestamp" to System.currentTimeMillis()
                )
                
                db.collection("chats").add(newChat).addOnSuccessListener { newDocRef ->
                    db.collection("friend_requests").document(req.id).delete().addOnSuccessListener {
                        Toast.makeText(holder.itemView.context, "Request accepted", Toast.LENGTH_SHORT).show()
                        val intent = Intent(holder.itemView.context, ChatActivity::class.java)
                        intent.putExtra("chatId", newDocRef.id)
                        intent.putExtra("chatName", req.senderUsername)
                        holder.itemView.context.startActivity(intent)
                    }
                }
            }
        }
    }

    override fun getItemCount() = requests.size
}
