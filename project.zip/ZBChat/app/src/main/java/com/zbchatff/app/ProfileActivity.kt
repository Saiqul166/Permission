package com.zbchatff.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val currentUser = auth.currentUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.profileToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Profile"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val tvEmail = findViewById<TextView>(R.id.tvEmail)
        val etUsername = findViewById<EditText>(R.id.etUsername)
        val btnSave = findViewById<Button>(R.id.btnSave)

        tvEmail.text = currentUser?.email ?: ""

        if (currentUser != null) {
            db.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        etUsername.setText(doc.getString("username") ?: "")
                    }
                }
        }

        btnSave.setOnClickListener {
            val newUsername = etUsername.text.toString().trim()
            if (newUsername.isEmpty()) {
                Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if username already exists
            db.collection("users").whereEqualTo("username", newUsername).get()
                .addOnSuccessListener { snapshot ->
                    if (!snapshot.isEmpty && snapshot.documents[0].id != currentUser?.uid) {
                        Toast.makeText(this, "Username already taken", Toast.LENGTH_SHORT).show()
                    } else {
                        // Update
                        if (currentUser != null) {
                            val updates = hashMapOf(
                                "username" to newUsername,
                                "searchName" to newUsername.lowercase()
                            )
                            db.collection("users").document(currentUser.uid)
                                .set(updates, com.google.firebase.firestore.SetOptions.merge())
                                .addOnSuccessListener {
                                    val builder = androidx.appcompat.app.AlertDialog.Builder(this)
                                    builder.setTitle("Success")
                                    builder.setMessage("Profile updated successfully!")
                                    builder.setPositiveButton("OK") { dialog, _ ->
                                        dialog.dismiss()
                                        finish()
                                    }
                                    val dialog = builder.create()
                                    dialog.show()
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this, "Failed to update profile: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to check username: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }
    }
}
